About
=====
F5 version 2. Easier to use.

Acknowledge
===========
Thanks to @island205's original `f5`

